import shutil
import datetime
import os

def create_backup():
    # Get current date and time
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    
    # Define zip filename
    zip_filename = f"backup_{timestamp}"
    
    # Get current directory
    source_dir = os.getcwd()
    
    # Create the zip file
    # make_archive will add .zip extension automatically
    output_path = os.path.join(source_dir, zip_filename)
        
    print(f"Zipping files from: {source_dir}")
    
    try:
        # Create zip, avoiding recursive loop (don't include other zips if possible, 
        # though make_archive handles the output file being outside usually, 
        # here we are putting it inside, so we need to be careful not to zip the zip if we run it widely)
        # But for simplicity, we focus on the app folder.
        
        # To be cleaner, let's zip the current folder keys
        shutil.make_archive(zip_filename, 'zip', source_dir)
        
        print(f"Success! Backup created: {zip_filename}.zip")
    except Exception as e:
        print(f"Error creating backup: {e}")

    input("\nPress Enter to exit...")

if __name__ == "__main__":
    create_backup()
