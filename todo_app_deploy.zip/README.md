# Modern Full-Stack To-Do App

A robust, database-backed Task Management application built with Python (Flask) and a modern, responsive frontend.

## 🌟 Features

*   **Persistent Storage**: Uses SQLite database.
*   **Categories & Priorities**: Set Priority (High/Medium/Low) and Due Dates.
*   **Search Integration**: One-click Google Search for tasks.
*   **Modern UI**: Glassmorphism design, Dark Mode, and responsive layout.
*   **CRUD Operations**: Create, Read, Update, Delete tasks effortlessly.

## 🛠️ Tech Stack

*   **Backend**: Python, Flask, SQLite
*   **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
*   **Fonts/Icons**: Google Fonts (Inter), FontAwesome

## 🚀 How to Run

1.  **Clone the repository** (or download files).
2.  **Install dependencies**:
    ```bash
    pip install -r requirements.txt
    ```
3.  **Run the application**:
    ```bash
    python app.py
    ```
4.  **Open in Browser**:
    Go to `http://127.0.0.1:5000`

## 📂 Project Structure

- `app.py`: Main backend application logic.
- `todo.db`: SQLite database (created automatically).
- `tasks.txt`: Legacy data file (migrated automatically).
- `templates/`: HTML files (`index.html`, `edit.html`).
- `static/`: CSS and Javascript files.
